"use strict";

module.exports = {
  rules: {
    "no-var": "off",
  },
};
