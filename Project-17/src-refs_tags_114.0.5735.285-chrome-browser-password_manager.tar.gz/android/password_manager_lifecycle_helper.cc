// Copyright 2022 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "chrome/browser/password_manager/android/password_manager_lifecycle_helper.h"

PasswordManagerLifecycleHelper::~PasswordManagerLifecycleHelper() {}
